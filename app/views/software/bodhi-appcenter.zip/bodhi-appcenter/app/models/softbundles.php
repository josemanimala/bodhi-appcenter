<?php
class Softbundles extends AppModel
{
  var $name = 'Softbundles';
  var $primaryKey = 'id';
}
?>
