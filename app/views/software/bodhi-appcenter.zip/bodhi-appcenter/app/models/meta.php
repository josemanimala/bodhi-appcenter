<?php
class Meta extends AppModel
{
  var $name = 'Meta';
  var $primaryKey = 'id';
}
?>
