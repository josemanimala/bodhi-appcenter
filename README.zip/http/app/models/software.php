<?php
class Software extends AppModel
{
  var $name = 'Software';
  var $primaryKey = 'id';
}
?>
